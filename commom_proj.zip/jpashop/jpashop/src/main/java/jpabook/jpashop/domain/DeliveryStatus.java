package jpabook.jpashop.domain;

public enum DeliveryStatus {
    //READY , COMP
}
